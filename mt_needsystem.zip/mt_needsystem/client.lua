local hunger = 100
local thirst = 100
local sleep = 100
local tickRate = 60000

local function Translate(key)
    if Config.Language == "dk" then
        local texts = {
            hungry = "Du er meget sulten!",
            thirsty = "Du er meget tørstig!",
            tired = "Du er meget træt!",
            ate = "Du spiste noget mad!",
            drank = "Du drak noget vand!",
            no_food = "Du har ingen mad i inventory!",
            no_drink = "Du har ingen drikke i inventory!",
            sleeping = "Du sover...",
            rested = "Du føler dig udhvilet!"
        }
        return texts[key]
    else
        local texts = {
            hungry = "You are very hungry!",
            thirsty = "You are very thirsty!",
            tired = "You are very tired!",
            ate = "You ate some food!",
            drank = "You drank some water!",
            no_food = "You have no food in your inventory!",
            no_drink = "You have no drink in your inventory!",
            sleeping = "You are sleeping...",
            rested = "You feel rested!"
        }
        return texts[key]
    end
end

local function ShowNotification(text, type)
    lib.notify({ title = "Needs System", description = text, type = type or "inform" })
end

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(tickRate)
        hunger = math.max(hunger - 2, 0)
        thirst = math.max(thirst - 3, 0)
        sleep = math.max(sleep - 1, 0)

        if hunger <= 20 then ShowNotification(Translate("hungry"), "error") end
        if thirst <= 20 then ShowNotification(Translate("thirsty"), "error") end
        if sleep <= 20 then ShowNotification(Translate("tired"), "error") end
    end
end)

local function ApplyPlayerEffects()
    local ped = PlayerPedId()
    local health = GetEntityHealth(ped)
    local stamina = 1.0
    local moveRate = 1.0
    local blur = 0.0

    if hunger <= Config.SlowMovementHunger or sleep <= Config.SlowMovementSleep then
        moveRate = 0.5
        SetPedMoveRateOverride(ped, 0.5)
        SetRunSprintMultiplierForPlayer(PlayerId(), 0.5)
    else
        moveRate = 1.0
        SetPedMoveRateOverride(ped, 1.0)
        SetRunSprintMultiplierForPlayer(PlayerId(), 1.0)
    end

    if hunger <= Config.LowStaminaHunger or sleep <= Config.LowStaminaSleep then
        stamina = 0.5
    end
    if thirst <= Config.LowStaminaThirst then
        stamina = 0.3
    end
    RestorePlayerStamina(PlayerId(), stamina)

    if hunger <= 0 then SetEntityHealth(ped, math.max(health - Config.HealthPenaltyHunger, 0)) end
    if sleep <= 0 then SetEntityHealth(ped, math.max(health - Config.HealthPenaltySleep, 0)) end
    if thirst <= 0 then SetEntityHealth(ped, math.max(health - Config.HealthPenaltyThirst, 0)) end

    blur = 0.0
    if hunger <= Config.BlurEffectHunger then blur = blur + 0.2 end
    if sleep <= Config.BlurEffectSleep then blur = blur + 0.2 end
    if thirst <= Config.BlurEffectThirst then blur = blur + 0.2 end
    SetTimecycleModifierStrength(blur)
    if blur > 0 then SetTimecycleModifier("spectator5") else ClearTimecycleModifier() end
end

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(1000)
        ApplyPlayerEffects()
    end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(Config.DehydrationEffectInterval)
        local ped = PlayerPedId()
        local health = GetEntityHealth(ped)
        if thirst <= 0 then
            SetEntityHealth(ped, math.max(health - Config.DehydrationHealthLoss, 0))
        end
    end
end)

RegisterCommand("eat", function()
    if exports.ox_inventory:Search('count', Config.FoodItem) > 0 then
        exports.ox_inventory:RemoveItem(Config.FoodItem, 1)
        lib.progressBar({ duration = Config.EatDuration, label = Translate("ate"), useWhileDead = false, canCancel = true, disable = {move=true,car=true,combat=true} })
        TaskPlayAnim(PlayerPedId(), "mp_player_inteat@burger", "mp_player_int_eat_burger_fp", 8.0, 1.0, -1, 49, 0, false, false, false)
        Citizen.Wait(Config.EatDuration)
        ClearPedTasks(PlayerPedId())
        hunger = math.min(hunger + Config.HungerRestore, 100)
    else
        ShowNotification(Translate("no_food"), "error")
    end
end, false)

RegisterCommand("drink", function()
    if exports.ox_inventory:Search('count', Config.DrinkItem) > 0 then
        exports.ox_inventory:RemoveItem(Config.DrinkItem, 1)
        lib.progressBar({ duration = Config.DrinkDuration, label = Translate("drank"), useWhileDead = false, canCancel = true, disable = {move=true,car=true,combat=true} })
        TaskPlayAnim(PlayerPedId(), "mp_player_intdrink", "loop_bottle", 8.0, 1.0, -1, 49, 0, false, false, false)
        Citizen.Wait(Config.DrinkDuration)
        ClearPedTasks(PlayerPedId())
        thirst = math.min(thirst + Config.ThirstRestore, 100)
    else
        ShowNotification(Translate("no_drink"), "error")
    end
end, false)

RegisterCommand("sleep", function()
    lib.progressBar({ duration = Config.SleepDuration, label = Translate("sleeping"), useWhileDead = false, canCancel = true, disable = {move=true,car=true,combat=true} })
    TaskStartScenarioInPlace(PlayerPedId(), "WORLD_HUMAN_SLEEPING", 0, true)
    Citizen.Wait(Config.SleepDuration)
    ClearPedTasks(PlayerPedId())
    sleep = math.min(sleep + Config.SleepRestore, 100)
end, false)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(1000)
        SetTextFont(0)
        SetTextProportional(1)
        SetTextScale(0.35, 0.35)
        SetTextColour(255, 255, 255, 255)
        SetTextEntry("STRING")
        AddTextComponentString("Hunger: "..hunger.."% | Thirst: "..thirst.."% | Sleep: "..sleep.."%")
        DrawText(0.015, 0.955)
    end
end)
