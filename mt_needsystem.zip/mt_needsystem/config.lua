Config = {}

Config.Language = "dk"

Config.FoodItem = "bread"
Config.DrinkItem = "water"

Config.HungerRestore = 25
Config.ThirstRestore = 25
Config.SleepRestore = 50

Config.SleepDuration = 10000
Config.EatDuration = 5000
Config.DrinkDuration = 5000

Config.SlowMovementHunger = 20
Config.SlowMovementSleep = 20

Config.LowStaminaHunger = 30
Config.LowStaminaSleep = 30
Config.LowStaminaThirst = 40

Config.HealthPenaltyHunger = 5
Config.HealthPenaltyThirst = 7
Config.HealthPenaltySleep = 5

Config.DehydrationEffectInterval = 5000
Config.DehydrationHealthLoss = 5

Config.BlurEffectHunger = 10
Config.BlurEffectThirst = 10
Config.BlurEffectSleep = 10
