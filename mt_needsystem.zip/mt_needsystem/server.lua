local playerNeeds = {}

AddEventHandler('playerConnecting', function(name, setKickReason, deferrals)
    local src = source
    playerNeeds[src] = {hunger=100, thirst=100, sleep=100}
end)

AddEventHandler('playerDropped', function(reason)
    local src = source
    playerNeeds[src] = nil
end)

RegisterNetEvent('mt_needsystem:getNeeds')
AddEventHandler('mt_needsystem:getNeeds', function()
    local src = source
    if playerNeeds[src] then
        TriggerClientEvent('mt_needsystem:updateNeeds', src, playerNeeds[src].hunger, playerNeeds[src].thirst, playerNeeds[src].sleep)
    end
end)

RegisterNetEvent('mt_needsystem:setNeeds')
AddEventHandler('mt_needsystem:setNeeds', function(h, t, s)
    local src = source
    if playerNeeds[src] then
        playerNeeds[src].hunger = h
        playerNeeds[src].thirst = t
        playerNeeds[src].sleep = s
    end
end)
