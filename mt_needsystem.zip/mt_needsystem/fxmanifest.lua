fx_version 'cerulean'
game 'gta5'

author 'MTCore'
description 'MT Needs System, Support at https://discord.mtcore.dk'
version '1.0.0'

client_scripts {
    'config.lua',
    'client.lua'
}

server_scripts {
    'config.lua',
    'server.lua'
}

dependencies {
    'ox_inventory',
    'ox_lib'
}
